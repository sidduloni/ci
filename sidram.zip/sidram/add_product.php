<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Add Product</title>
<script src="js/jquery.min.js" type="text/javascript"></script>
<script src="js/bind.js" type="text/javascript"></script>
</head>
<?php include("session.php"); ?>
<body>
<a  href="logout.php">
<button style="float:right;">Logout</button>
</a>
<center>
  <h1>Product Management</h1>
</center>
<hr>
<br>
<a href="home.php" >
<button>Product List</button>
</a><br>
<br>
<center>
  <pre>

<h2><u>Add Product</u></h2>
<form action="add_product_submit.php" method="post" enctype="multipart/form-data">
<table cellpadding="5">
<tr><td><label>Select category : </label></td><td><select name="category" id="category">
  <option >Category</option>
  <?php    	$query="select * from category_master";
                $result=mysqli_query($link,$query);	
							
				while($row=mysqli_fetch_assoc($result))
				{
					$id=$row['cid'];
					$cname=$row['cname'];					
					echo '<option value="'.$id.'">'.$cname.'</option>'; 
				}
				mysqli_close($link);
          ?>
  </select></td></tr>

<tr><td><label>Select product : </label></td><td><select name="product" id="product">
  <option >Product</option>
  </select>
</td></tr>
<tr><td><label>Select price : </label></td><td><select name="price" id="price">
  <option >Price</option>
  </select>
</td></tr>

<tr><td><label>Select quantity : </label></td><td><select name="qty" id="qty">
  <option >Quantity</option>
  <option>1</option>
  <option>2</option>
  <option>3</option>
  <option>4</option>
  <option>5</option>
  <option>6</option>
  <option>7</option>
  <option>8</option>
  <option>9</option>
  <option>10</option>
  </select>
</td></tr>
<tr><td><label>Select image : </label></td><td><input type="file" name="file_img" id="image" /></td></tr>
<tr><td></td><td ><input type="submit" name="proceed" value="Proceed" onClick="return confirm('Are you sure?')" /></td></tr>
</table>
</form>
</pre>
</center>
</body>
</html>