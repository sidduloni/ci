<?php

include("session.php");

if(isset($_POST['proceed']))
   {
	    $category1=$_POST['category'];
	    $product1=$_POST['product'];
	    $price1=$_POST['price'];
		$qty=$_POST['qty'];
		
		$q1=mysqli_query($link,"select cname from category_master where cid='$category1'");
		$q1_row=mysqli_fetch_assoc($q1);
		$category=$q1_row['cname'];
		
		$q2=mysqli_query($link,"select product_name from product_master where cid='$category1' and product_id='$product1'");
		$q2_row=mysqli_fetch_assoc($q2);
		$product=$q2_row['product_name'];
		
		$q3=mysqli_query($link,"select price from price_master where cid='$category1' and product_id='$product1' and price_id='$price1'");
		$q3_row=mysqli_fetch_assoc($q3);
		$price=$q3_row['price'];
		
		$filetmp = $_FILES["file_img"]["tmp_name"];
	$filename = $_FILES["file_img"]["name"];
	$filetype = $_FILES["file_img"]["type"];
	$filepath = "uploads/".$filename;
	
	move_uploaded_file($filetmp,$filepath);
		
		$image=$filepath;
		
$inserted=mysqli_query($link,"insert into product(category,product_name,price,qty,image,action) values('$category','$product','$price','$qty','$image','')");

if($inserted)
{
	header("location: home.php");
}
else{
	header("location: add_product.php");
}
   }
   

?>