<?php
session_start();
$error='';
if(isset($_POST['submit']))
{ 
if(empty($_POST['uname']) || empty($_POST['password']))
{
	$error="User ID/Password Is Invalid";
}
else
{
$userid=$_POST['uname'];
$pwd=$_POST['password'];

include("connect.php");
$userid=stripslashes($userid);
$pwd=stripslashes($pwd);
$userid=mysqli_real_escape_string($link,$userid);
$pwd=mysqli_real_escape_string($link,$pwd);

$login_query=mysqli_query($link,"select * from login where uid='$userid' and pwd='$pwd'");
$count=mysqli_num_rows($login_query);
if($count==1)
   {
	$_SESSION['user_session']=$userid;
	header("Location: add_product.php");
    }
else{	
    $error="User ID or Password Is Invalid";	
    }
mysqli_close($link);
} // else close 
} // if close
?>
