<?php 
include("session.php");
if(isset($_POST['category_id']))
{
    $id=$_POST['category_id'];
		
   $query="select * from product_master where cid='$id'";
   $result=mysqli_query($link,$query);
				while($row=mysqli_fetch_assoc($result))
				{
				     $id=$row['product_id'];
					$pname=$row['product_name'];
					echo '<option value="'.$id.'">'.$pname.'</option>';
				  
				}
				
}
else if(isset($_POST['product_id']))
{
	 $id=$_POST['product_id'];
	 
   $query="select * from price_master where product_id='$id'";
   $result=mysqli_query($link,$query);
				while($row=mysqli_fetch_assoc($result))
				{
				     $id=$row['price_id'];
					$price=$row['price'];
					echo '<option value="'.$id.'">'.$price.'</option>';
				  
				}
	
}

?>
