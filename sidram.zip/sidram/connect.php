
<?php
$link=mysqli_connect('localhost','root','root');
if(!$link)
{ die("not connected<br>" . mysqli_connect_error());}
else{	echo "<br>";}

$db=mysqli_select_db($link,"product");
		if(!$db)
		{
			die("no db" . mysqli_error($link));
			}
			else{
			echo "";
			} 


?>
