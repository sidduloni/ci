-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 05, 2017 at 07:14 PM
-- Server version: 5.7.17-log
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `product`
--

-- --------------------------------------------------------

--
-- Table structure for table `category_master`
--

CREATE TABLE IF NOT EXISTS `category_master` (
  `cid` int(11) NOT NULL,
  `cname` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `category_master`
--

INSERT INTO `category_master` (`cid`, `cname`) VALUES
(1, 'mobile'),
(2, 'tv');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` varchar(50) NOT NULL,
  `pwd` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `uid`, `pwd`) VALUES
(1, 'admin', 'admin123');

-- --------------------------------------------------------

--
-- Table structure for table `price_master`
--

CREATE TABLE IF NOT EXISTS `price_master` (
  `cid` int(50) NOT NULL,
  `product_id` int(50) NOT NULL,
  `price_id` int(50) NOT NULL,
  `price` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `price_master`
--

INSERT INTO `price_master` (`cid`, `product_id`, `price_id`, `price`) VALUES
(1, 1, 1, '10000'),
(1, 2, 2, '200000'),
(1, 3, 3, '300000'),
(1, 4, 4, '25000'),
(1, 5, 5, '3500000'),
(1, 6, 6, '420000'),
(2, 1, 1, '23000'),
(2, 1, 2, '212455'),
(2, 2, 2, '236452'),
(2, 3, 4, '542242'),
(2, 4, 3, '365245'),
(2, 5, 5, '562432'),
(2, 1, 1, '32564'),
(2, 2, 2, '654513216'),
(2, 3, 3, '6565656'),
(2, 3, 3, '648575'),
(2, 4, 4, '64896'),
(2, 5, 5, '65485'),
(2, 6, 6, '64896'),
(2, 7, 7, '36258'),
(2, 8, 8, '9568'),
(2, 9, 9, '96589'),
(2, 10, 10, '89556'),
(2, 11, 11, '9554'),
(2, 12, 12, '36521'),
(2, 13, 13, '89565'),
(2, 14, 14, '65874'),
(1, 14, 14, '6584'),
(1, 10, 8, '65232'),
(2, 5, 9, '54654'),
(1, 5, 3, '6465'),
(2, 6, 8, '9654');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE IF NOT EXISTS `product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(50) NOT NULL,
  `product_name` varchar(50) NOT NULL,
  `price` varchar(50) NOT NULL,
  `qty` varchar(50) NOT NULL,
  `image` varchar(255) NOT NULL,
  `action` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `category`, `product_name`, `price`, `qty`, `image`, `action`) VALUES
(1, 'mobile', 'lenova', '', '3', 'uploads/download (2).jpg', ''),
(2, 'mobile', 'samsung', '3500000', '5', 'uploads/download (1).jpg', 'deleted'),
(3, 'tv', 'Sansui', '', '2', 'uploads/download (7).jpg', 'deleted'),
(4, 'tv', 'Intex', '36521', '3', 'uploads/images (6).jpg', ''),
(5, 'mobile', 'samsung', '3500000', '6', 'uploads/images (1).jpg', ''),
(6, 'mobile', 'samsung', '3500000', '4', 'uploads/download (2).jpg', ''),
(7, 'tv', 'Sansui', '', '7', 'uploads/images (5).jpg', ''),
(8, 'mobile', 'oppo', '', '8', 'uploads/download (6).jpg', ''),
(9, 'tv', 'Sony', '96589', '6', 'uploads/images (3).jpg', '');

-- --------------------------------------------------------

--
-- Table structure for table `product_master`
--

CREATE TABLE IF NOT EXISTS `product_master` (
  `cid` int(50) NOT NULL,
  `product_id` int(50) NOT NULL,
  `product_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `product_master`
--

INSERT INTO `product_master` (`cid`, `product_id`, `product_name`) VALUES
(1, 1, 'micromax'),
(1, 2, 'lg'),
(1, 3, 'lenova'),
(1, 4, 'htc'),
(1, 5, 'samsung'),
(1, 6, 'oppo'),
(1, 7, 'mi'),
(1, 8, 'lyf'),
(2, 9, 'Sony'),
(2, 10, 'Sansui'),
(2, 11, 'LG'),
(2, 12, 'Intex');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
