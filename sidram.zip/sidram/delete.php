<?php 

include("session.php");

if(isset($_GET['delete_id']))
{
	$idd=$_GET['delete_id'];
	$qq=mysqli_query($link,"update product set action='deleted' where id='$idd'");
	
	if($qq)
	{
		header("location: home.php");
	}
	else{
	echo "error deletion";	
	}
}

?>