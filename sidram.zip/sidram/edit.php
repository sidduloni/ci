<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Edit Page</title>
<?php include("session.php"); ?>
</head>

<body>
<?php
if(isset($_POST['edit_submit']))
{
	$edit_id=$_POST['edit_id'];
	$result=mysqli_query($link,"select * from product where action='' and id='$edit_id'");
	$row=mysqli_fetch_array($result);
	?>
<center>
  <form action="edit.php" method="post">
    <input type="hidden" name="edited_id" value="<?php echo $row['id']; ?>">
    <input type="text" name="category" value="<?php echo $row['category']; ?>">
    <br>
    <input type="text" name="product" value="<?php echo $row['product_name']; ?>">
    <br>
    <input type="text" name="price" value="<?php echo $row['price']; ?>">
    <br>
    <input type="text" name="qty" value="<?php echo $row['qty']; ?>">
    <br>
    <input type="submit" name="edited_submit" value="DONE"/>
    <input type="reset" name="reset" value="Reset"/>
  </form>
</center>
<?php
}
else if(isset($_POST['edited_submit']))
{
	$edit_id=$_POST['edited_id'];
	$query=mysqli_query($link,"update product set category='$_POST[category]',product_name='$_POST[product]',price='$_POST[price]', qty='$_POST[qty]' where id='$edit_id'");


header("Location: home.php");
}

?>
</body>
</html>