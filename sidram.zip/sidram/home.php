<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Home Page</title>
<style>
button {
	cursor: pointer;
}
input[type=submit], [type=reset] {
	cursor: pointer;
}
</style>
<script>
function confirmDelete()
{
if(confirm("Are sure to delete ?"))	
	{
		return true;
	}
	else
	{
	return false;	
	}
	
}
</script>
</head>
<?php include("session.php"); ?>
<body>
<a  href="logout.php">
<button style="float:right;">Logout</button>
</a>
<center>
  <h1>Product Management</h1>
</center>
<hr>
<br>
<a href="add_product.php" >
<button>Add Product</button>
</a><br>
<br>
<center>
  <?php 
  if(isset($_POST['edit_submit']))
{
	$edit_id=$_POST['edit_id'];
	$result=mysqli_query($link,"select * from product where action='' and id='$edit_id'");
	$row=mysqli_fetch_array($result);
	?>
  <center>
    <form action="edit.php" method="post">
      <input type="hidden" name="edited_id" value="<?php echo $row['id']; ?>">
      <input type="text" name="category" value="<?php echo $row['category']; ?>">
      <input type="text" name="product" value="<?php echo $row['product_name']; ?>">
      <input type="text" name="price" value="<?php echo $row['price']; ?>">
      <input type="text" name="qty" value="<?php echo $row['qty']; ?>">
      <br>
      <input type="submit" name="edited_submit" value="DONE"/>
      <input type="reset" name="reset" value="Reset"/>
    </form>
    <a href="Home.php">
    <button>Cancel</button>
    </a>
  </center>
  <?php
}
else if(isset($_POST['edited_submit']))
{
	$edit_id=$_POST['edited_id'];
	$query=mysqli_query($link,"update product set category='$_POST[category]',product_name='$_POST[product]',price='$_POST[price]', qty='$_POST[qty]' where id='$edit_id'");


echo "Edit Success !";
}

  
   ?>
  <br>
  <table border="1" cellpadding="4" cellspacing="5">
    <tr>
      <td>Sl.No</td>
      <td>Category</td>
      <td>Product</td>
      <td>Price</td>
      <td>Quantity</td>
      <td>Image</td>
      <td>Edit</td>
      <td>Delete</td>
    </tr>
    <?php 
	
	$limit=5;
	@$page=$_GET['p'];
	if($page == '')
	{
		$start=0;
		//$page=1;
		
	}
	else
	{
	$start=$limit*($page-1);	
	}
	
  $query=mysqli_query($link,"select * from product where action='' limit $start, $limit");
  $sl_num=$start+1;
  
  while($row=mysqli_fetch_array($query))
  {
	?>
    <tr>
      <?php
	  $id=$row['id'];
	echo "<td>" .$sl_num.  "</td>";
	echo "<td>" . $row['category'].  "</td>";
	echo "<td>" . $row['product_name'].  "</td>";
	echo "<td>" . $row['price'].  "</td>";
	echo "<td>" . $row['qty'].  "</td>";
	echo "<td><img height='50' weight='50' src='" . $row['image'].  "'/></td>";
	?>
      <td><form method="post" action="Home.php">
          <input type="hidden" name="edit_id" value="<?php echo $id; ?>">
          <input type="submit" name="edit_submit" value="EDIT"/>
        </form></td>
      <?php
	echo "<td> <a onclick='return confirmDelete()' href='delete.php?delete_id=$id'><button>DELETE</button></a></td>";
	?>
    </tr>
    <?php
		$sl_num++;  
  } 
 
  ?>
  </table>
  <br>
  <?php 
   $num_rec=mysqli_query($link,"select * from product where action=''");
  $records=mysqli_num_rows($num_rec);
  $num_page_rec=ceil($records/$limit);
 
  if($num_page_rec > 1)
  {
	  for( $i=1; $i<=$num_page_rec;$i++)
	  {
      echo "<a href='home.php?p=$i'><button>".$i."</button></a>";
	  }
	  
  }
  
  ?>
</center>
</body>
</html>
