<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Login</title>
</head>
<?php include("adminlog.php"); 
if(isset($_SESSION['user_session']))
{
	header("Location: add_product.php");
}
?>
<body>
<center>
  <h1>Login</h1>
  <?php echo $error; ?>
  <form action="" method="post">
    <input type="text" name="uname" placeholder="User ID" required />
    <br>
    <br>
    <input type="password" name="password" placeholder="Password" required />
    <br>
    <br>
    <input type="submit" name="submit" value="Login"/>
    &nbsp;&nbsp;
    <input type="reset" name="reset" value="Reset" />
  </form>
</center>
</body>
</html>