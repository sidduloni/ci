$(document).ready(function(e) {

 $("#category").change(function(e) {
    var categ_var=$("#category").val();
	 if($(this).val()=='Category')
	 {
		alert("Please select category"); 
	 }
	 else
	 {		
		 $.post("bind.php",{category_id:categ_var},function(data){
			 $("#product").html(data);
			  
			 });
	 }
});

     	 $("#product").change(function(e) {
    var prod_var=$("#product").val();
	 if($(this).val()=='Product')
	 {
		alert("Please select product"); 
	 }
	 else
	 {		
			   $.post("bind.php",{product_id:prod_var},function(data){
				  
				   $("#price").html(data);   
			   });
			
	 }
});
});