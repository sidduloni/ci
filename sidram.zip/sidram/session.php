<?php
session_start();
include("connect.php");
$session_check=$_SESSION['user_session'];
$result=mysqli_query($link,"select uid from login where uid='$session_check'");
$res=mysqli_fetch_assoc($result);
if(!$res)
{
	mysqli_close($link);
header("Location: index.php");	
}

?>